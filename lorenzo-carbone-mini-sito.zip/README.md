# Mini sito di Lorenzo Carbone

Questo pacchetto contiene il file `index.html` pronto per la pubblicazione su GitHub Pages, Netlify o qualsiasi hosting statico.

## Istruzioni rapide (GitHub Pages)
1. Crea un repository chiamato `lorenzocarbone.github.io`.
2. Carica `index.html` nella root del repository.
3. Vai all'URL `https://lorenzocarbone.github.io` dopo qualche minuto.

## Istruzioni rapide (Netlify)
1. Vai su https://app.netlify.com/drop
2. Trascina il file `index.html`.
3. Copia l'URL generato.
